/**
 * 
 */
package com.pavuluri.springCacheDemo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pavuluri.springCacheDemo.beans.Student;
import com.pavuluri.springCacheDemo.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService sService;
	
	@PostMapping("/student")
	public String addStudent(@RequestBody Student student) {		
		StudentService.getInstance().addStudent(student);		
		return "Added succesfully";		
	}
	
	@GetMapping("/student/{id}")
	public Student getStudentById(@PathVariable String id) {
		System.out.println("Searching for Id");
		return StudentService.getInstance().getStudentById(id);
	}
		
	@PutMapping("/student/{id}")
	public Student updateStudent(@RequestBody Student student) {
		return StudentService.getInstance().updateStudent(student);		
	}
	
	@DeleteMapping("/student/all")
	public String deleteAll() {
		return StudentService.getInstance().deleteStudentsFromMapAndCache();		
	}
	
	@DeleteMapping("/student/cache")
	public String deleteCache() {
		return StudentService.getInstance().deleteStudentsFromCacheOnly();		
	}
	
	@DeleteMapping("/student/{id}")
	public String deleteStudentById(@PathVariable String id) {
		return StudentService.getInstance().deleteStudentByIdFromCacheAndMap(id);	
	}
	
	@PutMapping("/config/delay")
	public String configDelay(@RequestBody Map<String, Object> configValue) {
		System.out.println(configValue.get("value"));
		int value = (Integer)configValue.get("value");
		
		//return "test";
		return StudentService.getInstance().configDelay(Long.valueOf(value));		
	}
}
