/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;


public class Student {

	private String sName;
	private String sId;
	private String address;		
	private int age;
	private String level;	
	
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsId() {
		return sId;
	}
	public void setsId(String sId) {
		this.sId = sId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setLevel(String enumValue) {
		StudentLevelEnum enumV = StudentLevelEnum.valueOf(enumValue);
		this.level = enumV.getAcLevel();
	}
	
	public String getLevel() {
		return level;
	}
}
