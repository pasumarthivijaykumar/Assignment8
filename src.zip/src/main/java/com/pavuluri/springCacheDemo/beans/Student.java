/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;

import com.pavuluri.springCacheDemo.service.StudentService.levelEnum;

public class Student {

	private String sName;
	private String sId;
	private String address;		
	private int age;
	private String level;	
	
	/*public Student(String sId, String sName, String sAddress, int age) {
		super();
		this.sId = sId;
		this.sName = sName;
		this.address = sAddress;
		this.age = age;
	}*/
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsId() {
		return sId;
	}
	public void setsId(String sId) {
		this.sId = sId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setLevel(levelEnum freshman) {		
		this.level = freshman.toString();
	}	
}
