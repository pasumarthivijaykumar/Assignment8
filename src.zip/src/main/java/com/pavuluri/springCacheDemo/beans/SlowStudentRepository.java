/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class SlowStudentRepository implements IStudentRepository{

	@Override
	@Cacheable("students")
	public Student getStudentById(int sId) {
		sleepQuery(1200L);
		return null;
	}

	private void sleepQuery(long l) {		
		try {
			Thread.sleep(l);
		}catch(InterruptedException e) {
			throw new IllegalStateException(e);
		}
	}

}
