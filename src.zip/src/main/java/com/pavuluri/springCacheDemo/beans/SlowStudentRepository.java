/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;

import java.util.HashMap;
import java.util.Map;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class SlowStudentRepository implements IStudentRepository{

	private Map<String, Student> studentMap = new HashMap<>();
	
	private static SlowStudentRepository studentRepository = null;
	
	private long delayValue = 1000L;
	
	private SlowStudentRepository() {
		studentMap = new HashMap<>();
	}
	
	public static SlowStudentRepository getInstance() {
		if(studentRepository == null) {
			studentRepository = new SlowStudentRepository();
			return studentRepository;
		}else {
			return studentRepository;
		}
	}
	
	@Cacheable("students")
	public void addStudent(Student student) {
		studentMap.put(student.getsId(), student);
	}
	
	@Override
	@Cacheable(value="students", key="student.sId")
	public Student getStudentById(String sId) {
		sleepQuery(delayValue);
		return studentMap.get(sId);
	}

	private void sleepQuery(long l) {		
		try {
			Thread.sleep(l);
		}catch(InterruptedException e) {
			throw new IllegalStateException(e);
		}
	}
	
	@CachePut(value="students", key = "#student.sId" , unless="#result==null")
	public Student updateStudent(Student student) {
		Student stu = null;
		for (String sId : studentMap.keySet()) {
			if(sId.equals(student.getsId())) {
				stu = studentMap.get(sId);
				stu.setAddress(student.getAddress());
				stu.setAge(student.getAge());
				stu.setsName(student.getsName());
				stu.setLevel(student.getLevel());
				return stu;
			}
		}		
		return null;
	}

	//This method will remove all 'students' from cache.
	@CacheEvict(value = "students", allEntries = true)
    public String deleteStudentsFromCacheOnly() {
		return "students are removed from cache only.";
    }
	
	//This method will remove only this specific product from students cache and map.
	@CacheEvict(value = "students"  ,  key = "#student.sId")
	public String deleteStudentByIdFromCacheAndMap(String sId) {	    
		if(studentMap.containsKey(sId)) {
			studentMap.remove(sId);
			return "student with id"+sId+" is removed from map and cache.";
		}
		return "student with id="+sId+" is not available.";
	}
	
	private String removeStudentsFromMap() {
		if(studentMap.isEmpty()) {
			return "Students Map and Cache are already empty.";
		}
		studentMap.clear();
		return "Students Map and Cache are cleared.";
	}
	
	@CacheEvict(value = "students", allEntries = true)
	public String deleteStudentsFromMapAndCache() {
		return removeStudentsFromMap();
	}
	
	public String configDelay(long value) {
		delayValue = value;
		return "delay is set.";
	}

}
