/**
 * 
 */
package com.pavuluri.springCacheDemo.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.pavuluri.springCacheDemo.beans.Student;

@Service
public class StudentService {
	
	private Map<String, Student> studentMap = new HashMap<>();
	
	private static StudentService studentService = null;
	
	private long delayValue = 1000L;
	
	public static enum levelEnum{
		freshman, sophomore, junior, senior
	}
	
	private StudentService() {
		studentMap = new HashMap<>();
	}
	
	public static StudentService getInstance() {
		if(studentService == null) {
			studentService = new StudentService();
			return studentService;
		}else {
			return studentService;
		}
	}
	
	@Cacheable(value="students", key="student.sId")
	public Student getStudentById(String sId) {
		/* try {
			Thread.sleep(1200L);
		} catch (InterruptedException e) {
			throw new IllegalStateException(e);
		} */
		sleepQuery(delayValue);
		//return new Student(sId, "anu", "v", 3);
		return studentMap.get(sId);
	}
	
	@CachePut(value="students", key = "#student.sId" , unless="#result==null")
	public Student updateStudent(Student student) {
		Student stu = null;
		for (String sId : studentMap.keySet()) {
			if(sId == student.getsId()) {
				stu = studentMap.get(sId);
				stu.setAddress(student.getAddress());
				stu.setAge(student.getAge());
				stu.setsName(student.getsName());
				return stu;
			}
		}
		
		return null;
	}

	@Cacheable("students")
	public void addStudent(Student student) {
		student.setLevel(levelEnum.freshman);
		studentMap.put(student.getsId(), student);
	}

	//This method will remove all 'students' from cache.
	@CacheEvict(value = "students", allEntries = true)
    public String deleteStudentsFromCacheOnly() {
		return "students are removed from cache only.";
    }
	
	//This method will remove only this specific product from students cache and map.
	@CacheEvict(value = "students"  ,  key = "#student.sId")
	public String deleteStudentByIdFromCacheAndMap(String sId) {	    
		if(studentMap.containsKey(sId)) {
			studentMap.remove(sId);
			return "student with "+sId+" is removed from map and cache.";
		}
		return "student with "+sId+" is not available.";
	}
	
	private String removeStudentsFromMap() {
		if(studentMap.isEmpty()) {
			return "Students Map is already empty";
		}
		studentMap.clear();
		return "Students Map is cleared.";
	}
	
	@CacheEvict(value = "students", allEntries = true)
	public String deleteStudentsFromMapAndCache() {
		return removeStudentsFromMap();
	}
	
	private void sleepQuery(long l) {		
		try {
			Thread.sleep(l);
		}catch(InterruptedException e) {
			throw new IllegalStateException(e);
		}
	}

	public String configDelay(long value) {
		delayValue = value;
		return "delay is set.";
	}
	
}
